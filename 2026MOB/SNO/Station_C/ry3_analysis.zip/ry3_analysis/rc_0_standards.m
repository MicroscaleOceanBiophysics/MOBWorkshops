% RY3 Single Image Calibration for Experimental Standards
%
% The raw and unmixed viscosity standard image files are loaded and the 
% mean fluorescence intensities are converted to viscosity relative to the 
% initial calibration curve. If saveout, saves standard viscosities and 
% ratios to rstd.xs.xo, where xs is the experiment ID and xo is the optical
% config ID. This data is used by rc_b_calib for calibrating experimental 
% images.
%
% reqs: bioformats, rc.mat, ryoc.mat, rstd.mat

% -------------------------------------------------------------------------
% SET UP 
% -------------------------------------------------------------------------

clearvars

% NAMES and FILES----------------------------------------------------------
xs='e01';       % rstd identifier (experiment id, e.g. 'e01')
xo='r15';       % Optical config ID (e.g. 'r15_2' for 2nd set of standards
                % imaged during experiment)
fld='C:/path/to/experiment/directory'; % Directory location of files
fns={'m0001_r15.nd2';
     'g0030_r15.nd2';
    }; % Raw standard file names in order of increasing viscosity (e.g. m01; g30)
saveout=true; % Save output to rstd?

% CALIBRATION PARAMETERS---------------------------------------------------
cmr=18.7647;    % Measured visc ratio (e.g. original g30/m01 = 18.7647)
oc450=15;       % 450 optical config (default=15)
oc650=15;       % 650 optical config (default=15)
wv450=3:5;      % Raw blue intensities bins (default=3:5)
wv650=26;       % Raw red intensities bins (default=26)
co=[50 100 200 400 800]; % Concentrations RY3 (default=[50 100 200 400 800])
stind=1;        % Skip low-visc points? (stind>1)
ftp='semi';     % Fit type of ratio to viscosity (default='semi')
pw=1.1;         % Ratio denominator power (alpha tuning parameter, default=1.1)
um=1;           % Use unmixed? (default=1)
stn={'m01';'g30'}; % Standard IDs, should match cmr
satlvl=4095; % Saturation value (12 bit: 0:4095)

% INITIALIZE---------------------------------------------------------------
load rc.mat;    % Calibration data
load ryoc.mat;  % Optical configurations
visc=r.vc;      % Visc type: r.vc:corrected
outnm={'ebl','ery'}; % Output struct var names
lf={'r','u'}; % Which file to use for each out var
ch={3:5,2}; % Channels: um 1-syb, 2-ry3, 3-chl, 4-rem. raw 3:5-424:444

s=0; % Which image series (java index)

%% ------------------------------------------------------------------------
% MAIN LOADING LOOP
% -------------------------------------------------------------------------
tic
for oj=1:length(fns)
for oi=1:length(outnm)

% -------------------------------------------------------------------------
% READER and METADATA
% -------------------------------------------------------------------------

% Set ND2 Reader-----------------------------------------------------------
if lf{oi}=='r'
    rdr = bfGetReader([fld '/' fns{oj}]); % Load raw file
else
    rdr = bfGetReader([fld '/um_' fns{oj}]); % Load unmixed file
end

rdr.setSeries(s); % set the series
rdm = rdr.getMetadataStore(); % OME metadata

% Reader Info
fpa = char(rdr.getCurrentFile()); % Current file path
fnm = fpa(find(fpa=='\',1,'last')+1:end); % Current file name
sc = rdr.getSeriesCount();  % Series Count
cc = rdr.getSizeC();        % Channel Count (including transmitted)
xc = rdr.getSizeX();        % X Pixel Count
yc = rdr.getSizeY();        % Y Pixel Count
zc = rdr.getSizeZ();        % Z-stack Count
tc = rdr.getSizeT();        % Time series Count
pc = rdr.getImageCount();   % Total Planes Count = cc*zc*tc

% OME Info
mpp = double(rdm.getPixelsPhysicalSizeX(s).value()); % microns per pixel
if zc>1
    mpz = double(rdm.getPixelsPhysicalSizeZ(s).value()); % dz microns
else
    mpz=0;
end

% Channels
chn = [];  % Unmixed channel names
iin = []; % t indicies of unmixed channels (matlab)
tin = []; % t indicies of transmitted
for t = 0:cc-1 % java index
    chn{t+1}=char(rdm.getChannelName(s,t));
    if ~strcmp(chn{t+1},'Transmitted') % exclude transmitted
        iin = [iin t+1]; %#ok<*AGROW>
    else
        tin = [tin t+1];
    end
end

%fprintf([fnm ': ' outnm{oi}]); % status (file)

% -------------------------------------------------------------------------
% LOAD IMAGES
% -------------------------------------------------------------------------

em=zeros(yc,xc,zc); % emission container
for c=1:length(ch{oi})
    for i=1:zc
        em(:,:,i)=em(:,:,i)+double(bfGetPlaneAtZCT(rdr,i,ch{oi}(c),1));
    end
end
em=em/length(ch{oi}); % mean of channels
rdr.close();

% Find saturated pixels in ery---------------------------------------------
if all(outnm{oi}=='ery')
    satpx=find(em==satlvl);
end

% Save image to output struct
im.(outnm{oi})=em;

% -------------------------------------------------------------------------
% END MAIN 'oi' LOOP
% -------------------------------------------------------------------------
end

%% ------------------------------------------------------------------------
% CALIBRATION DATA SETUP
% -------------------------------------------------------------------------

% Set up the basic emission ratios for each conc and viscosity
for i=1:length(co)
    ind450(i,:)=find(r.oc == oc450 & r.co == co(i))';   %#ok<*SAGROW> 
    ind650(i,:)=find(r.oc == oc650 & r.co == co(i))';
    
    e_numu(i,:)=r.umn(ind650(i,:))'; % unmixed e_num numerator   
    e_numr(i,:)=mean(r.emn(ind650(i,:),wv650),2)'; % raw e_num numerator
    e_den(i,:)=mean(r.emn(ind450(i,:),wv450),2)'; % raw e_den denominator
end

% Skip low viscosities?
ind450=ind450(:,stind:end); 
ind650=ind650(:,stind:end);
e_numu=e_numu(:,stind:end);
e_numr=e_numr(:,stind:end);
e_den=e_den(:,stind:end);

% Viscosities
vi=visc(ind450(1,:)); 
viscvec=reshape(visc(ind450)',[],1);

%% ------------------------------------------------------------------------
% RATIO AND FITS
% -------------------------------------------------------------------------

% Fit unmixed to raw/unmixed intensities factor----------------------------
[xData, yData] = prepareCurveData( e_numu(:), e_numr(:)./e_numu(:) );
ft = fittype( '1+a/(x+b)', 'independent', 'x', 'dependent', 'y' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Robust = 'Bisquare';
opts.StartPoint = [0.0357116785741896 0.849129305868777];
[fru, gfu] = fit( xData, yData, ft, opts );
fu=@(n) n.*(1+fru.a./(n+fru.b)); % function to multiply um by factor

% Ratio--------------------------------------------------------------------
if um
    e_num=fu(e_numu); % adjusted unmixed
else
    e_num=e_numr; % raw 
    fu=@(n) n; % if only using raw, don't use factor
end

e_rat=e_num./(e_den.^pw); 
e_ratvec=reshape(e_rat',[],1);

vln=log(viscvec);
ern=log(e_ratvec);

% Fit ratio to viscosities-------------------------------------------------
warning('off','curvefit:fit:noStartPoint')
switch ftp

    % Fit ln v = a*exp(b*ln r) --> v = exp(a*r^b)
    case 'exp1'
    [xData, yData] = prepareCurveData( ern, vln ); % ln input
    ft = fittype( 'exp1' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to ln
    ff=@(n) exp(fr.a * n.^fr.b); % Fit function, normal input

    % Fit ln v = a*exp(b*ln r) + c --> v = exp(a*r^b + c)
    case 'exp2'
    [xData, yData] = prepareCurveData( ern, vln ); % ln input
    ft = fittype( 'a*exp(b*x)+c', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to ln
    ff=@(n) exp(fr.c + fr.a * n.^fr.b); % Fit function, normal input

    % Fit ln v = a*(ln r)^b --> v = exp(a*(ln r)^n)
    case 'pwr'
    [xData, yData] = prepareCurveData( ern, vln ); % ln input
    ft = fittype( 'power1' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to ln
    ff=@(n) exp(fr.a * log(n).^fr.b); % Fit function, normal input

    % Fit ln v = a*exp(ln r) + b --> v = exp(a*r+b)
    case 'semi' % semi: ln v = a*r+b
    [xData, yData] = prepareCurveData( ern, vln ); % ln input
    ft = fittype( 'a*exp(x)+b', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.Robust = 'Bisquare';   
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to semi-ln
    ff=@(n) exp(fr.a * n + fr.b); % Fit function, normal input

    % Fit v = exp(a*r)
    case 'exp0'
    [xData, yData] = prepareCurveData( e_ratvec, viscvec ); % normal input
    ft = fittype( 'exp(a*x+b)', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.Robust = 'Bisquare';   
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to ln
    ff=@(n) exp(fr.a * n + fr.b); % Fit function, normal input

    otherwise
    error('Unknown fit type')
end
warning('on','curvefit:fit:noStartPoint')

% Predict viscosities from fit
v_pre=ff(e_rat);
v_prevec=reshape(v_pre',[],1);

%% ------------------------------------------------------------------------
% CALIBRATE IMAGES
% -------------------------------------------------------------------------

enf=mean(im.ery,'all');
edf=mean(im.ebl,'all');

vis(oj)=ff(fu(enf)./edf.^pw);

% -------------------------------------------------------------------------
% END MAIN 'oj' LOOP
% -------------------------------------------------------------------------
end

gmr=vis(2)/vis(1);
disp([stn{1} ': ' num2str(vis(1)) ', ' stn{2} ': ' num2str(vis(2)) ]);
disp(['gmr: ' num2str(gmr) ', cmr: ' num2str(cmr)]);


%% ------------------------------------------------------------------------
% SAVE FILE
% -------------------------------------------------------------------------

if saveout
    load rstd.mat;  % Viscosity standards per experiment
    rstd.(xs).(xo).(stn{1})=vis(1);
    rstd.(xs).(xo).(stn{2})=vis(2);
    rstd.(xs).(xo).gmr=gmr;
    rstd.(xs).(xo).cmr=cmr;
    save('vm/rstd.mat','rstd');
end

