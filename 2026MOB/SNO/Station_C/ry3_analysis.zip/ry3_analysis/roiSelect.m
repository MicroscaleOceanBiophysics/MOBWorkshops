function roip = roiSelect(img,clm,pixelThresh,roiPos)
%  roip = ROISELECT creates a GUI for selection of rectangle ROIs in a 
%  default z-stack and returns ROI Positions for each z-plane in a cell 
%  array. The default pixel count goal is 200^2. The image color scale is 
%  log10. There is no check for overlapping ROIs.
%
%  roip = ROISELECT(img) uses the specified 2-D or 3-D image.
%
%  roip = ROISELECT(img,clm) also defines the color scale limits as 'auto'  
%  or [cmin cmax].
%
%  roip = ROISELECT(img,clm,pixelThresh) also defines the pixel count goal.
%
%  roip = ROISELECT(img,clm,pixelThresh,roiPos) also pre-populates the ROIs 
%  using roiPos, a size(img,3) x 1 cell array. 
%
%
%  Note: requires Image Processing Toolbox

arguments
    img {mustBeNumeric,mustBeFinite,mustBeReal,mustBeImage(img)} ...
        = double(tiffreadVolume('mri.tif'));
    clm {mustBeClim(clm)} = 'auto';
    pixelThresh {mustBeNumeric,mustBeFinite,mustBeReal} = 200^2;
    roiPos cell {mustBeSize(img,roiPos)} = cell(size(img,3),1);  
end

im=double(img);
cl=clm;
pxth=pixelThresh;
rz=roiPos;

% Parameters
zi=1; % Z-plane index
[yc,xc,zc]=size(im); % y,x pixel and Z-plane count
drawing=0; % Current state of draw ROI flag
pc=zeros(zc,1); % ROI pixel count container
for j=1:length(rz)
    if ~isempty(rz{j}) % If roiPos supplied, prepopulate pixel counts
        pc(j)=sum(rz{j}(:,3).*rz{j}(:,4));
    end
end

% Create ui figure
fig = uifigure("Name","roiSelect");
g = uigridlayout(fig,[3 4]);
g.RowHeight = {'fit','1x','fit'};
g.ColumnWidth = {80,'1x','1x',80}; % {'fit','1x','1x','fit'}

% Position ui figure (upper left corner, last monitor)
mpos=get(0,"MonitorPositions");
fig.Position = [mpos(end,1)+25 ...
    mpos(end,2)+0.5*mpos(end,4)-50 ...
    0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];

% Create ui elements
ax = uiaxes(g);
ax.Layout.Row = 2;
ax.Layout.Column = [1 4];
ax.Toolbar.Visible = 'off';

bp = uibutton(g, ...
    "Text","Prev", ...
    "ButtonPushedFcn", @prevButtonPushed);
bp.Layout.Row = 3;
bp.Layout.Column = 1;

bn = uibutton(g, ...
    "Text","Next", ...
    "ButtonPushedFcn", @nextButtonPushed);
bn.Layout.Row = 3;
bn.Layout.Column = 4;

bd = uibutton(g, "state",...
    "Text","Draw", ...
    "ValueChangedFcn", @drawButtonPushed);
bd.Layout.Row = 3;
bd.Layout.Column = 3;

be = uibutton(g, ...
    "Text","End Session", ...
    "ButtonPushedFcn", @endButtonPushed);
be.Layout.Row = 1;
be.Layout.Column = 4;

lc0 = uilabel(g,"Text","Z-Plane: ","HorizontalAlignment","right");
lc0.Layout.Row = 1;
lc0.Layout.Column = 1;

lc = uilabel(g,"Text",sprintf("%d / %d",zi,zc));
lc.Layout.Row = 1;
lc.Layout.Column = 2;

lp = uilabel(g,"Text",sprintf("Pixel Count: %d / %d",pc(zi),pxth));
lp.Layout.Row = 3;
lp.Layout.Column = 2;

% Initialize plot
updatePlot;

ax.PlotBoxAspectRatioMode='manual';
ax.PlotBoxAspectRatio=[xc/yc 1 1];
ax.XLim=[1 xc];
ax.YLim=[1 yc];
ax.Box='on';
ax.XTick=[];
ax.XTickLabel='';
ax.YTick=[];
ax.YTickLabel='';

waitfor(fig); % Wait for figure to close before returning roip output

% UI Functions

    function prevButtonPushed(~,~)
        if zi>1
            zi=zi-1;
            updatePlot;
        end        
    end

    function nextButtonPushed(~,~)
        if zi<zc
            zi=zi+1;
            updatePlot;
        end
    end

    function updatePlot
        cla(ax);
        imagesc(ax,im(:,:,zi));
        set(ax,'ColorScale','log'); % Log10 color scale
        clim(ax,cl);
        lc.Text = sprintf("%d / %d",zi,zc);
        lp.Text = sprintf("Pixel Count: %d / %d",pc(zi),pxth);
        if pc(zi)>=pxth
            lp.FontColor=[0.09 0.54 0.32];
        else
            lp.FontColor='k';
        end
        
        if ~isempty(rz{zi})
            for i=1:size(rz{zi},1) % Redraw previous ROIs
                rectangle(ax,'Position',rz{zi}(i,:),'EdgeColor','r');
            end
        end
    end
        
    function drawButtonPushed(~,event)
        if event.Value % Toggle on
            drawing=1;
            drawmore=1; % Continue drawing ROIs
            ri=0; % ROI counter for zi

            bp.Enable='off'; % Disable other buttons while drawing
            bn.Enable='off';
            be.Enable='off';

            % Redraw any previous ROIs
            if ~isempty(rz{zi}) % Check for previous ROIs on zi
                for i=1:size(rz{zi},1) % Redraw previous ROIs
                    ri=ri+1;
                    rzt(ri)=drawrectangle(ax,'Position',rz{zi}(i,:));
                end
                reply=questdlg('Add more ROIs?','','Yes','No','No');
                if strcmpi(reply,'No')
                    drawmore=0;
                end
            end          
            
            % New ROI drawing loop
            while drawing
                % Draw new or edit old ROIs
                if drawmore % Draw new ROIs
                    ri=ri+1;
                    rzt(ri)=drawrectangle(ax);                   
                else % Edit old ROIs
                    pause; % Prevent runaway while loop, wait for user
                end
                drawnow % Updates plot, checks drawing status

                % ROI pixel count 
                pc(zi)=0; % Reset pixel count
                for i=1:ri % Update pixel count
                    if isvalid(rzt(i)) % Check for valid ROI (not deleted)
                        tpos=rzt(i).Position(3:4); % Width, Height
                        pc(zi)=pc(zi)+round(tpos(1))*round(tpos(2));
                    end
                end
                lp.Text = sprintf("Pixel Count: %d / %d",pc(zi),pxth);
                if pc(zi)>=pxth
                    lp.FontColor=[0.09 0.54 0.32];
                else
                    lp.FontColor='k';
                end
            end

            if drawmore % Removes extra roi caused by while loop
                delete(rzt(ri)); 
                ri=ri-1;
            end
            
            % Save ROI positions to rz
            rz{zi}=[]; % Reset
            if ~isempty(rzt)
                ctr=0;
                for i=1:ri % Save ROI positions
                    if isvalid(rzt(i)) % Check for valid ROI (not deleted)
                        ctr=ctr+1;
                        rz{zi}(ctr,:)=round(rzt(i).Position);
                    end
                end
            end

            updatePlot;

        else % Toggle off
            drawing=0;
            if pause('query') % Auto turn off pause from drawmore=0 
                pause('off')
            end
            bp.Enable='on'; % Disable other buttons after drawing
            bn.Enable='on';
            be.Enable='on';
        end
    end

    function endButtonPushed(~,~)
        roip=rz;        
        close(fig);
    end

end

% Function argument validation

function mustBeImage(img)
    s=size(img);
    if numel(s)<2 || numel(s)>3 || s(1)==1 || s(2)==1
        error('Input img must have 2 or 3 dimensions.');
    end
end

function mustBeClim(clm)
    if ~strcmp(clm,'auto') && numel(clm)~=2
        error('Input clm must be ''auto'' or two-element vector of the form [cmin cmax].')
    end
end

function mustBeSize(img,roiPos)
    si=size(img);
    sr=size(roiPos);
    if numel(si)==3 % 3-D
        if si(3)~=sr(1) || sr(2)~=1 || numel(sr)~=2
            error('Input roiPos must be size(img,3) x 1 cell.');
        end
    else % 2-D
        if sr(1)~=1
            error('Input roiPos must be 1 x 1 cell for 2-D img.');
        end
    end
end