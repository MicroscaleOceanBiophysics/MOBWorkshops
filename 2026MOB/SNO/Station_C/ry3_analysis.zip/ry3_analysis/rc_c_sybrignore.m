% RC C SybrIgnore
%
% View the SYBR ‘b’ images next to thresholded images with labelled
% connected components (bacteria and other cell objects). This is used for
% testing SYBR thresholds and identifying objects to include or exclude
% from the rc_c_halos.m analysis.
%
% reqs: rc_b output, Image Processing Toolbox (bwconncomp, sliceViewer),
%       

clearvars

% FILES--------------------------------------------------------------------
nm='e01_m09r15'; % Filename
load([nm '_b.mat']); % Load output from rc_b

% ANALYSIS PARAMETERS------------------------------------------------------
syth = 25; % SYBR threshold for detecing bacteria (25)
bact_rad = 0.35; % Radius (um) of min sphere bact sybr signal

% INITIALIZE---------------------------------------------------------------
im = b; % Image struct from loaded file (rc_b output)
vim=im.vim;esf=im.esf;mpp=im.m.mpp;mpz=im.m.mpz;
vox=mpp*mpp*mpz; % Voxel volume (um^3)

% Min connected pixels cutoff for a sphere sybr signal = bacterium
min_bact_size = round( (4/3)*pi*(bact_rad^3)/vox );

%% ------------------------------------------------------------------------
% SYBR CONNECTED COMPONENTS
% -------------------------------------------------------------------------

% Locate connected sybr pixels above thresholds
symask=esf>=syth; % Find pixels greater than SYBR threshold
symask_cc=bwconncomp(symask,26); % Label individual clusters (26=3D cubic)
[~,I] = sort(cellfun(@length,symask_cc.PixelIdxList),'descend');
symask_cc.PixelIdxList=symask_cc.PixelIdxList(I); % Sort by size
numvgt=cellfun(@numel,symask_cc.PixelIdxList); % Pixels per cluster
insmal=find(numvgt <= min_bact_size); % Identify < bact-sized clusters

symask_cc.PixelIdxList(insmal)={[]}; % Remove small entires

symask_lab=labelmatrix(symask_cc); % Labelled components

% Construct colormap with 0=black and the rest lines()
cm=[0 0 0; lines(max(symask_lab(:)))];


%% ------------------------------------------------------------------------
% FIGURES
% -------------------------------------------------------------------------

% Comparative views of log10 SYBR and SYBR conn comps
mpos=get(0,"MonitorPositions"); [yc,xc,zc]=size(esf);

f(1)=figure('Name',[im.m.nm ': log10 SYBR']);
s(1)=sliceViewer(esf);
% f(1).Position=[mpos(end,1)+25 ...
%     mpos(end,2)+0.5*mpos(end,4)-50 ...
%     0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
colormap gray;
clim auto;
set(gca,'ColorScale','log')

f(2)=figure('Name',[im.m.nm ': SYBR concomp, syth=' int2str(syth)]);
s(2)=sliceViewer(symask_lab);
% f(2).Position=[mpos(end,1)+50+0.5*mpos(end,4)*xc/yc ...
%     mpos(end,2)+0.5*mpos(end,4)-50 ...
%     0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
colormap(cm);
 
% Link the sliceViewer sliders
addlistener(s(1), 'SliderValueChanging', ...
    @(src,evt) updateSliceNumber(s(1), s(2)));

addlistener(s(2), 'SliderValueChanging', ...
    @(src,evt) updateSliceNumber(s(2), s(1)));

% Bacterial volume statistics
for i=1:symask_cc.NumObjects
    bvx(i)=numel(symask_cc.PixelIdxList{i}); %#ok<SAGROW>
end
bvx(bvx==0)=[];
baco=sum(ceil(bvx/(min_bact_size*5))); % Conservative bact count
figure('Name',[im.m.nm ': bact vol, syth=' int2str(syth) ', bact obj: '...
    int2str(max(symask_lab(:))) ', bact cnt: ' int2str(baco)]);
histogram(bvx*vox,0:.05:10);
xlim([0 2]);
xlabel 'Bact volume (um^3)';
ylabel 'Count'

function updateSliceNumber(s1, s2)
    % Update the SliceNumber property of s2 to match s1
    s2.SliceNumber = s1.SliceNumber;
end

