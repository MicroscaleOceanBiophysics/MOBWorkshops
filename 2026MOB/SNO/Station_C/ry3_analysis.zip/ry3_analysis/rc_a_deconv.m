% RC A Deconvolution 
%
% For a single experimental sample, both the raw and unmixed files are
% loaded and the raw blue RY3 (I_B), unmixed red RY3 (I_R), and SYBR Green 
% channels are extracted. All channels are deconvolved with the point
% spread function of the microscope and the resulting image matrices and
% metadata are saved out as a single struct (labelled ‘a’).
% 
% reqs: bioformats, psf.mat

% -------------------------------------------------------------------------
% SET UP 
% -------------------------------------------------------------------------

clearvars

% FILES AND TRUNCATION-----------------------------------------------------
nm='e01_m09r15';
fld='C:/path/to/experiment/directory'; % Directory location of files
fnr='e01_m09_r15.nd2'; % Raw file name
fns=['vm/data/' nm '_a.mat']; % Save file name
psc='vm/psf.mat'; % PSF file name

ztrunc=7:33; % Truncate z stack? (Keep only these z-indices). Default []

plotfig=true; % Plot before and after deconv figures?
saveout=true; % Save _a output file?

% DECONV PARAMETERS--------------------------------------------------------
sum1=true; % PSF sum to 1?
iter=3; % Deconv iterations
dmpr=0; % Damp threshold. Default 0
rdot=0; % Specify additive noise. Default 0. Unused if nhood is specified  
nhood=[3 3]; % Estimate noise? 0=no, [m n] is neighborhood for nu estimate
satlvl=4095; % Saturation value (12 bit: 0:4095)

% INITIALIZE---------------------------------------------------------------
outnm={'ebl','ery','esy'}; % Output struct var names
lf={'r','u','u'}; % Which file to use for each out var
ch={3:5,2,1}; % Channels: um 1-syb, 2-ry3, 3-chl, 4-rem. raw 3:5-424:444

s=0; % Which image series (java index)
load(psc); % Load PSF

%% ------------------------------------------------------------------------
% MAIN LOOP
% -------------------------------------------------------------------------
tic
for o=1:length(outnm)

% -------------------------------------------------------------------------
% READER and METADATA
% -------------------------------------------------------------------------

% Set ND2 Reader-----------------------------------------------------------
if lf{o}=='r'
    rdr = bfGetReader([fld '/' fnr]);
else
    rdr = bfGetReader([fld '/um_' fnr]);
end

rdr.setSeries(s); % set the series
rdm = rdr.getMetadataStore(); % OME metadata

% Reader Info
fpa = char(rdr.getCurrentFile()); % Current file path
fnm = fpa(find(fpa=='\',1,'last')+1:end); % Current file name
sc = rdr.getSeriesCount();  % Series Count
cc = rdr.getSizeC();        % Channel Count (including transmitted)
xc = rdr.getSizeX();        % X Pixel Count
yc = rdr.getSizeY();        % Y Pixel Count
zc = rdr.getSizeZ();        % Z-stack Count
tc = rdr.getSizeT();        % Time series Count
pc = rdr.getImageCount();   % Total Planes Count = cc*zc*tc

% OME Info
mpp = double(rdm.getPixelsPhysicalSizeX(s).value()); % microns per pixel
if zc>1
    mpz = double(rdm.getPixelsPhysicalSizeZ(s).value()); % dz microns
else
    mpz=0;
end

% Channels
chn = [];  % Unmixed channel names
iin = []; % t indicies of unmixed channels (matlab)
tin = []; % t indicies of transmitted
for t = 0:cc-1 % java index
    chn{t+1}=char(rdm.getChannelName(s,t));  %#ok<SAGROW> 
    if ~strcmp(chn{t+1},'Transmitted') % exclude transmitted
        iin = [iin t+1];  %#ok<AGROW>
    else
        tin = [tin t+1];  %#ok<AGROW>
    end
end

if isempty(ztrunc)
    ztrunc=1:zc;
end

fprintf([fnm ': ' outnm{o}]); % status (file)

% -------------------------------------------------------------------------
% LOAD IMAGES
% -------------------------------------------------------------------------

em=zeros(yc,xc,zc); % emission container
for c=1:length(ch{o})
    for i=1:zc
        em(:,:,i)=em(:,:,i)+double(bfGetPlaneAtZCT(rdr,i,ch{o}(c),1));
    end
end
em=em/length(ch{o}); % mean of channels
rdr.close();

% Find saturated pixels in ery---------------------------------------------
if all(outnm{o}=='ery')
    satpx=find(em(:,:,ztrunc)==satlvl);
end

% -------------------------------------------------------------------------
% NOISE ESTIMATION
% -------------------------------------------------------------------------

if all(nhood)
    for i=1:zc
        locMn=filter2(ones(nhood),em(:,:,i)) / prod(nhood); % local mean
        locVr=filter2(ones(nhood),em(:,:,i).^2) / prod(nhood) - locMn.^2; % local variance
        nu(i)=sqrt(mean2(locVr)); % noise = std dev of the mean local variance
    end
    rdot=mean(nu);
end

% -------------------------------------------------------------------------
% DOWNSAMPLE PSF
% -------------------------------------------------------------------------

if o==1 % only necessary first loop
    % new resolution for psf
    xrn=mpp; % dx [um]
    zrn=mpz; % dz [um]
    
    % orig psf: emi, met
    mo=size(emi,1); % m,n (y,x) size
    oo=size(emi,3); % o (z) size
    mc=ceil(mo/2); % m,n center
    oc=ceil(oo/2); % o center
    
    xr=met.mpp; % x,y orig res
    zr=met.zs(2); % z orig res
    xv=xr*(-(mc-1):mc-1); % x,y vector (0 centered)
    zv=zr*(-(oc-1):oc-1); % z vector
    [X,Y,Z]=meshgrid(xv,xv,zv); % meshgrid
    
    % new size
    mn=floor(xr*(mo-1)/xrn); % new m,n (y,x) size
    on=floor(zr*(oo-1)/zrn); % new o (z) size
    if ~mod(mn,2); mn=mn-1;end % ensure odd
    if ~mod(on,2); on=on-1;end
    mcn=ceil(mn/2);
    ocn=ceil(on/2);
    
    xvn=xrn*(-(mcn-1):mcn-1); % x,y vector (0 centered)
    zvn=zrn*(-(ocn-1):ocn-1); % z vector
    [Xn,Yn,Zn]=meshgrid(xvn,xvn,zvn); % meshgrid
    
    % downsample
    psf=interp3(X,Y,Z,emi,Xn,Yn,Zn,'cubic',0);
    if sum1
        psf=psf./sum(psf(:));  
    end
end

% -------------------------------------------------------------------------
% DECONVOLUTION
% -------------------------------------------------------------------------

J=deconvlucy(em,psf,iter,dmpr,[],rdot);
J=J*sum(psf(:)); % scale by sum of psf, if needed

% Add truncated deconv zstack to output variable
a.(outnm{o})=J(:,:,ztrunc);

fprintf(' %3.1f min\n',toc/60); % status (file end)

% ------------------------------------------------------------------------
% FIGURES
% -------------------------------------------------------------------------

if plotfig && all(outnm{o}=='ery')
    mpos=get(0,"MonitorPositions"); [yc,xc,zc]=size(a.ery);

    f(1)=figure;
    sv(1)=sliceViewer(em(:,:,ztrunc));
    f(1).Position=[mpos(end,1)+25 ...
        mpos(end,2)+0.5*mpos(end,4)-50 ...
        0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
    clim auto
    set(gca,'ColorScale','log')
    set(f(1), 'Name', ['rc_a orig log: ' nm])
    
    f(2)=figure;
    sv(2)=sliceViewer(J(:,:,ztrunc));
    f(2).Position=[mpos(end,1)+50+0.5*mpos(end,4)*xc/yc ...
        mpos(end,2)+0.5*mpos(end,4)-50 ...
        0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
    clim auto
    set(gca,'ColorScale','log')
    set(f(2), 'Name', ['rc_a deconv log: ' nm])
    hold on
    plot([1 201 201],[201 201 1],'w')
    plot([823 823 1024],[1 201 201],'w')
    plot([1024 823 823],[823 823 1024],'w')
    plot([201 201 1],[1024 823 823],'w')
    hold off
     
    % Link the sliceViewer sliders
    addlistener(sv(1), 'SliderValueChanging', ...
        @(src,evt) updateSliceNumber(sv(1), sv(2)));
    
    addlistener(sv(2), 'SliderValueChanging', ...
        @(src,evt) updateSliceNumber(sv(2), sv(1)));

end

% -------------------------------------------------------------------------
% END MAIN 'o' LOOP
% -------------------------------------------------------------------------
end

% record metadata
a.m.nm=nm;
a.m.fn=fnr;
a.m.mpp=mpp;
a.m.mpz=mpz;
a.m.ztrunc=ztrunc;
a.m.satpx=satpx;
a.m.deconv.psc=psc;
a.m.deconv.iter=iter;
a.m.deconv.sum1=sum1;
a.m.deconv.dmpr=dmpr;
a.m.deconv.rdot=rdot;
a.m.deconv.nhood=nhood;

%% ------------------------------------------------------------------------
% SAVE FILE
% -------------------------------------------------------------------------

if saveout
    save(fns,'a');
end

% -------------------------------------------------------------------------
% FIGURE HELPER FUNCTION
% -------------------------------------------------------------------------

function updateSliceNumber(s1, s2)
    % Update the SliceNumber property of s2 to match s1
    s2.SliceNumber = s1.SliceNumber;
end
