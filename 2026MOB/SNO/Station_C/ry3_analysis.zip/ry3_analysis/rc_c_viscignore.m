% RC C1 ViscIgnore v.1 20240716e01_m09r15
% View visc connected components and grab IDs (via Data Tips) of unwanted 
% signals. Add the IDs to the ignore list (viig) in rc_c_halos.
%
% reqs: rc_b output, Image Processing Toolbox (bwconncomp, sliceViewer),
%       

clearvars

% FILES--------------------------------------------------------------------
nm='e01_m09r15'; % Filename
load([nm '_b.mat']); % Load output from rc_b

% ANALYSIS PARAMETERS------------------------------------------------------
vith = 2; % Visc threshold for aggregate region
bact_rad = 0.35; % Radius (um) of min sphere bact sybr signal

% INITIALIZE---------------------------------------------------------------
im = b; % Image struct from loaded file (rc_b output)
vim=im.vim;esf=im.esf;mpp=im.m.mpp;mpz=im.m.mpz;
vox=mpp*mpp*mpz; % Voxel volume (um^3)

% Min connected pixels cutoff for a sphere visc signal = bacterium
min_bact_size = round( (4/3)*pi*(bact_rad^3)/vox );
min_visc_size = min_bact_size*5; % min visc inside region > bacterium
min_visc_size2 = min_visc_size*5; % min visc edge region must be larger
                                  % due to more noise at lower visc

%% ------------------------------------------------------------------------
% VISC CONNECTED COMPONENTS
% -------------------------------------------------------------------------

% Locate connected visc pixels above threshold
vimask=vim >= vith; % Find pixels greater than visc threshold for edge
vimask_cc=bwconncomp(vimask,26); % Locate individual clusters (26=3D cubic)
[~,I] = sort(cellfun(@length,vimask_cc.PixelIdxList),'descend');
vimask_cc.PixelIdxList=vimask_cc.PixelIdxList(I); % Sort by size
numvgt=cellfun(@numel,vimask_cc.PixelIdxList); % Pixels per cluster
insm=find(numvgt <= min_visc_size2); % Identify < threshold-sized clusters
vimask_cc.PixelIdxList(insm)={[]}; % Remove small entires
vimask_lab=labelmatrix(vimask_cc); % Labelled components

% Construct colormap with 0=black and the rest lines()
cm=[0 0 0; lines(max(vimask_lab(:)))];

%% ------------------------------------------------------------------------
% FIGURES
% -------------------------------------------------------------------------
mpos=get(0,"MonitorPositions"); [yc,xc,zc]=size(vim);

f(1)=figure('Name',[im.m.nm ': log10 VIM']);
s(1)=sliceViewer(vim);
% f(1).Position=[mpos(end,1)+25 ...
%         mpos(end,2)+0.5*mpos(end,4)-50 ...
%         0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
colormap gray;
clim([1 5]);
set(gca,'ColorScale','log')

f(2)=figure('Name',[im.m.nm ': VIM concomp agg, vith=' num2str(vith)]);
s(2)=sliceViewer(vimask_lab);
% f(2).Position=[mpos(end,1)+40+0.5*mpos(end,4)*xc/yc ...
%         mpos(end,2)+0.5*mpos(end,4)-50 ...
%         0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
colormap(cm);
 
% Link the sliceViewer sliders
addlistener(s(1), 'SliderValueChanging', ...
    @(src,evt) updateSliceNumber(s(1), s(2)));

addlistener(s(2), 'SliderValueChanging', ...
    @(src,evt) updateSliceNumber(s(2), s(1)));

function updateSliceNumber(s1, s2)
    % Update the SliceNumber property of s2 to match s1
    s2.SliceNumber = s1.SliceNumber;
end

