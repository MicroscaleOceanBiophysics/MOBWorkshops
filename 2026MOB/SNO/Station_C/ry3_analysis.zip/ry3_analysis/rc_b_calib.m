% RC B Calibration
% 
% Loads the ‘a’ file, applies spatial filters, and calibrates the image
% matrices to viscosity relative to background and scaled by the viscosity
% standards. Saves out relative viscosity and SYBR image matrices and
% calibration metadata to a single struct (labelled ‘b’).
% 
% reqs: rc_a output, rc.mat, ryoc.mat, rstd.mat

% -------------------------------------------------------------------------
% SET UP 
% -------------------------------------------------------------------------
clearvars

% FILES--------------------------------------------------------------------
nm='e01_m09r15'; % Filename
load([nm '_a.mat']); % Load output from rc_a
fns=[nm '_b.mat']; % Save file name

plotfig=true; % Plot calib and image figures?
saveout=true; % Save out file?

% IMAGE PARAMETERS---------------------------------------------------------
ubg=true; % Use image bg for relative visc? False=relative to pure water
% Background ROI selection: for small val handling and relative visc
%    bgin={} if bg specified by rc_b_bgselect
     %    z,      rows,      cols           : 46:52, 1:201, 824:1024;
bgin={};

% Image filtering
mfwin=[5 5];    % Medfilt2 pixel window
gawin=5;        % Imgaussfilt sigma

% CALIBRATION PARAMETERS---------------------------------------------------
oc450=15;       % 450 optical config
oc650=15;       % 650 optical config
wv450=3:5;      % Raw blue intensities bins
wv650=26;       % Raw red intensities bins.
co=[50 100 200 400 800]; % Concentrations RY3
stind=1;        % Skip low-visc points? (stind>1)
ftp='semi';     % Fit type of ratio to viscosity
pw=1.1;         % Ratio denominator power
um=true;        % Use unmixed?
xs='';          % Optional rstd identifier (default='')
xg='';          % Optional end tag for rstd (default='')

% INITIALIZE---------------------------------------------------------------
load rc.mat;    % Calibration data
load ryoc.mat;  % Optical configurations
load rstd.mat;  % Viscosity standards per experiment
visc=r.vc;      % Visc type: r.vc:corrected

% Filter images
im=a; % Image struct from loaded file (rc_a output)
zc=length(im.m.ztrunc); % Z plane count
for i=1:zc % z planes
    enf(:,:,i)=medfilt2(im.ery(:,:,i),mfwin); % Numerator (red)
    edf(:,:,i)=imgaussfilt(im.ebl(:,:,i),gawin);  % Denominator (blue)
    esf(:,:,i)=medfilt2(im.esy(:,:,i),mfwin); % SYBR (green)
end

% Set up background
bg=false(size(im.ery)); % Background ROI
if ~isempty(bgin) % bg specified in this file as indices
    for i=1:size(bgin,1) % Rows of bgin
        for j=bgin{i,1}  % z planes
            bg(bgin{i,2},bgin{i,3},j)=true;
        end
    end
elseif isfield(im.m,'bgpos') % bg specified by rc_b_bgselect Positions
    bgin=im.m.bgpos;
    for i=1:length(bgin)
        for j=1:size(bgin{i},1)
            pt=bgin{i}(j,:);
            bg(pt(2):pt(2)+pt(4)-1,pt(1):pt(1)+pt(3)-1,i)=true;            
        end
    end
else
    error('Background not specified.');
end

%% ------------------------------------------------------------------------
% CALIBRATION DATA SETUP
% -------------------------------------------------------------------------

% Set up the basic emission ratios for each conc and viscosity
for i=1:length(co)
    ind450(i,:)=find(r.oc == oc450 & r.co == co(i))';   %#ok<*SAGROW> 
    ind650(i,:)=find(r.oc == oc650 & r.co == co(i))';
    
    e_numu(i,:)=r.umn(ind650(i,:))'; % unmixed e_num numerator   
    e_numr(i,:)=mean(r.emn(ind650(i,:),wv650),2)'; % raw e_num numerator
    e_den(i,:)=mean(r.emn(ind450(i,:),wv450),2)'; % raw e_den denominator
end

% Skip low viscosities?
ind450=ind450(:,stind:end); 
ind650=ind650(:,stind:end);
e_numu=e_numu(:,stind:end);
e_numr=e_numr(:,stind:end);
e_den=e_den(:,stind:end);

% Viscosities
vi=visc(ind450(1,:)); 
viscvec=reshape(visc(ind450)',[],1);

%% ------------------------------------------------------------------------
% RATIO AND FITS
% -------------------------------------------------------------------------

% Fit unmixed to raw/unmixed intensities factor----------------------------
[xData, yData] = prepareCurveData( e_numu(:), e_numr(:)./e_numu(:) );
ft = fittype( '1+a/(x+b)', 'independent', 'x', 'dependent', 'y' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Robust = 'Bisquare';
opts.StartPoint = [0.0357116785741896 0.849129305868777];
[fru, gfu] = fit( xData, yData, ft, opts );
fu=@(n) n.*(1+fru.a./(n+fru.b)); % function to multiply um by factor

% Ratio--------------------------------------------------------------------
if um
    e_num=fu(e_numu); % adjusted unmixed
else
    e_num=e_numr; % raw 
    fu=@(n) n; % if only using raw, don't use factor
end

e_rat=e_num./(e_den.^pw); 
e_ratvec=reshape(e_rat',[],1);

vln=log(viscvec);
ern=log(e_ratvec);

% Fit ratio to viscosities-------------------------------------------------
warning('off','curvefit:fit:noStartPoint')
switch ftp

    % Fit ln v = a*exp(b*ln r) --> v = exp(a*r^b)
    case 'exp1'
    [xData, yData] = prepareCurveData( ern, vln ); % ln input
    ft = fittype( 'exp1' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to ln
    ff=@(n) exp(fr.a * n.^fr.b); % Fit function, normal input

    % Fit ln v = a*exp(b*ln r) + c --> v = exp(a*r^b + c)
    case 'exp2'
    [xData, yData] = prepareCurveData( ern, vln ); % ln input
    ft = fittype( 'a*exp(b*x)+c', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to ln
    ff=@(n) exp(fr.c + fr.a * n.^fr.b); % Fit function, normal input

    % Fit ln v = a*(ln r)^b --> v = exp(a*(ln r)^n)
    case 'pwr'
    [xData, yData] = prepareCurveData( ern, vln ); % ln input
    ft = fittype( 'power1' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to ln
    ff=@(n) exp(fr.a * log(n).^fr.b); % Fit function, normal input

    % Fit ln v = a*exp(ln r) + b --> v = exp(a*r+b)
    case 'semi' % semi: ln v = a*r+b
    [xData, yData] = prepareCurveData( ern, vln ); % ln input
    ft = fittype( 'a*exp(x)+b', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.Robust = 'Bisquare';
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to semi-ln
    ff=@(n) exp(fr.a * n + fr.b); % Fit function, normal input

    % Fit v = exp(a*r)
    case 'exp0'
    [xData, yData] = prepareCurveData( e_ratvec, viscvec ); % normal input
    ft = fittype( 'exp(a*x+b)', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.Robust = 'Bisquare';
    [fr, gof] = fit( xData, yData, ft, opts ); % Fit to ln
    ff=@(n) exp(fr.a * n + fr.b); % Fit function, normal input

    otherwise
    error('Unknown fit type')
end
warning('on','curvefit:fit:noStartPoint')

% Predict viscosities from fit
v_pre=ff(e_rat);
v_prevec=reshape(v_pre',[],1);

%% ------------------------------------------------------------------------
% IMAGE PROCESSING
% -------------------------------------------------------------------------

% Set small vals to background ROI average to handle divde-by zeros and
% small value blowups
for i=1:zc % z planes
    edft=edf(:,:,i); % temp containers for each z plane
    enft=enf(:,:,i);
    bgt=bg(:,:,i);

    edft(edft<mean(edft(bgt),'all'))=mean(edft(bgt),'all'); % set small val
    enft(enft<mean(enft(bgt),'all'))=mean(enft(bgt),'all');

    edf(:,:,i)=edft; % reassign
    enf(:,:,i)=enft;
end

% Image ratio and fits to yield viscosity
vim=ff(fu(enf)./edf.^pw);

% Adjust new viscosity background to 1.
if isempty(xs)
    xs=nm(1:3);
end

for i=1:zc % z planes
    vimt=vim(:,:,i); % temp containers for each z plane    

    if ubg % viscosity relative to image bg
        bgt=bg(:,:,i);
        vimt=vimt/mean(vimt(bgt),'all');
    else % viscosity relative to pure water standard
        vimt=vimt/rstd.(xs).m01;
    end

    vim(:,:,i)=vimt; % reassign
end

% Scale by calib standard / experiment standard
vim=((rstd.(xs).(['r' int2str(oc650) xg]).cmr-1)...
    /(rstd.(xs).(['r' int2str(oc650) xg]).gmr-1))*(vim-1)+1;

% Package output
b.vim=vim; % viscosity
b.esf=esf; % sybr
b.m=im.m; % rc_a metadata
b.m.bgin=bgin;
b.m.calib.mfwin=mfwin;
b.m.calib.gawin=gawin;
b.m.calib.oc450=oc450;
b.m.calib.oc650=oc650;
b.m.calib.wv450=wv450;
b.m.calib.wv650=wv650;
b.m.calib.co=co;
b.m.calib.stind=stind;
b.m.calib.ftp=ftp;
b.m.calib.pw=pw;
b.m.calib.um=um;
b.m.calib.ubg=ubg;

%% ------------------------------------------------------------------------
% SAVE FILE
% -------------------------------------------------------------------------

if saveout
    save(fns,'b');
end

%% ------------------------------------------------------------------------
% FIGURES
% -------------------------------------------------------------------------

if plotfig

    % Intensities, ratios, fits--------------------------------------------
    figure;
    set(gcf, 'Name', ['Calib oc=' int2str(oc650)])

    subplot(2,3,1);
    loglog(vi,e_num,'.-');
    legend(cellstr(int2str(co')),'Location','southeast');
    grid on;
    ax=axis;
    xlabel 'Relative Viscosity'
    ylabel 'Mean Intensity'
    title 'U(I_R): RY3 red unmixed'
    
    subplot(2,3,2);
    loglog(vi,e_den,'.-');
    grid on;
    xlabel 'Relative Viscosity'
    ylabel 'Mean Intensity'
    title 'I_B: RY3 blue'
    
    subplot(2,3,3);
    loglog(vi,e_rat,'.-');
    hold on
    x1=10.^(-3:.01:4);
    loglog(ff(x1),x1,'k--')
    axis(ax)
    grid on;
    legend('','','','','','f_V Fit','Location','northwest');
    xlabel 'Relative Viscosity'
    ylabel 'Adjusted Ratio'
    title 'f_U(I_R)/I_B^a: Ratio'
    
    subplot(2,3,4);
    scatter(e_numu(:),e_numr(:)./e_numu(:),'.')
    hold on;
    plot(x1,fru(x1),'k--')
    xlim([min(e_numu(:))-100 max(e_numu(:))+100]);
    grid on;
    xlabel 'Unmixed Mean Intensity'
    ylabel 'Raw / Unmixed Mean Intensity'
    legend('','f_U Fit')
    title 'f_U: Fit'
    
    subplot(2,3,5)
    loglog(vi,v_pre,'.','markersize',15)
    hold on;
    loglog([.1 1000],[.1 1000],'-k')
    loglog([.1 1000],[.2 2000],'--k')
    loglog([.1 1000],[.05 500],'--k')
    grid on;
    legend('','','','','','1:1','Fx2','Location','northwest');
    xlabel 'Measured Viscosity'
    ylabel 'Predicted Viscosity'
    title 'Performance'
    
    subplot(2,3,6)
    histogram(log10(abs(v_prevec./viscvec)),-1:.025:1)
    axis([-1 1 0 6])
    hold on
    plot([-log10(2) -log10(2)],[0 6],'--k')
    plot([log10(2) log10(2)],[0 6],'--k')
    xlabel('log_{10}(abs(Pred/Meas))')
    ylabel('Number of Occurrences')
    title(['Performance Metric=' ...
        num2str(sum(abs(((v_prevec-viscvec)./viscvec))))])
    legend('','Factor of 2')
    
    % Processed images-----------------------------------------------------
    zm=ceil(zc/2); % Middle z plane

    figure
    set(gcf, 'Name', im.m.nm)

    subplot(2,2,1)
    imagesc(enf(:,:,zm));
    set(gca,'ColorScale','log')
    axis off image
    colorbar
    title('log_{10}(U(I_R))')
    
    subplot(2,2,2)
    imagesc(edf(:,:,zm));
    set(gca,'ColorScale','log')
    axis off image
    colorbar
    title 'log_{10}(I_B)'
    
    subplot(2,2,3)
    imagesc(esf(:,:,zm));
    set(gca,'ColorScale','log')
    axis off image
    colorbar
    title 'log_{10}(SYBR)'
    
    subplot(2,2,4)
    imagesc(real(vim(:,:,zm)));
    set(gca,'ColorScale','log')
    axis off image
    colorbar
    title 'log_{10}(Relative Viscosity)'

end

