% RC B BGSelect 
% 
% Background regions free of objects should be selected to
% calibrate the experimental images relative to background. This GUI allows
% rectangular regions to be drawn on each IR image plane and saves the
% coordinates to the corresponding ‘a’ file for use in rc_b_calib.m.
%
% reqs: rc_a output, roiSelect.m

clearvars;

% FILES AND PARAMETERS-----------------------------------------------------
nm='e01_m09r15'; % Filename
fns=[nm '_a.mat']; % Load/save output from rc_a
clm=[1 10]; % Color scale limits ('auto' or [cmin cmax] as per clim)
pxth=200^2; % Pixel count goal (default = 200^2)
saveout=true; % Save out file?

% BACKGROUND SELECTION-----------------------------------------------------
load(fns); % Load output from rc_a
im=a;
if isfield(im.m,'bgpos')
    bgpos=roiSelect(im.ery,clm,pxth,im.m.bgpos);
else
    bgpos=roiSelect(im.ery,clm,pxth);
end

% SAVE FILE----------------------------------------------------------------
if saveout
    a.m.bgpos=bgpos;
    save(fns,'a');
end