function [cc,cr]=cursorPos(cursorInfo)
% CURSORPOS Get positions from exported cursor data.
%   [cc,cr]=CURSORPOS(cursorInfo) cursorInfo is the exported cursor data
%   variable, image position is (cc = X cols, cr = Y rows).

    for i=1:numel(cursorInfo)
        cc(i)=cursorInfo(i).Position(1);
        cr(i)=cursorInfo(i).Position(2);
    end

end