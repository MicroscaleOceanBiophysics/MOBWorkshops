% RC C Halos 
%
% Loads the ‘b’ file, identifies bacterial objects, defines ‘halo’ regions
% around the bacteria, partitions mucus and non-mucus regions, and
% calculates the probability of viscosities in bacterial halos and regions.
% Saves out probability counts, relative viscosity image matrices for each
% partition, and associated metadata to a single struct (labelled ‘c’).
% 
% reqs: rc_b output, Image Processing Toolbox (bwconncomp), bwdistsc
%       
% optional: rc_c_sybrignore for sybr ignore list (syig), rc_c_viscignore
% for viscosity include/ignore list (viig).

% -------------------------------------------------------------------------
% SET UP 
% -------------------------------------------------------------------------
clearvars

% FILES--------------------------------------------------------------------
nm='e01_m09r15'; % Filename
load([nm '_b.mat']); % Load output from rc_b
plotfig = true; % Plot?
saveout = false; svst=''; % Save out file? And struct location (''=none).
xg=''; % Optional end tag for saveout file name (default='')

% ANALYSIS PARAMETERS------------------------------------------------------
syth = 25;    % SYBR threshold for detecing bacteria (agg=3)
vith = 2;     % Visc threshold for aggregate region
    
% IGNORE / INCLUDE / REMOVE
% SYBR conn comp to ignore for bact, from rc_c_sybrignore
syig = []; % []=none 

% Visc conn comp to: ig=ignore, in=include only
    %   syntax     : 'ig',[];...
viig={}; % {}=none
% Visc volume complete removal or keep by polygon vertices (col,row)
     %    z,      col vts,      row vts     : 22:45,[],[];...
virm={}; % {}=none

vike={}; % {}=none

% INITIALIZE---------------------------------------------------------------
bact_rad = 0.35; % Radius (um) of min sphere bact sybr signal (0.35)
bact_buffer = 0.4; % Buffer dist (um) from sybr = bact (0.4)
halo_delta = 0.3; % Halo thickness (um) (0.3)
edg_buffer = 0.8; % Buffer dist (um) from vth2 = edge region (0.8)

im = b; % Image struct from loaded file (rc_b output)
vim=im.vim;esf=im.esf;mpp=im.m.mpp;mpz=im.m.mpz;
vox=mpp*mpp*mpz; % Voxel volume (um^3/vox)

% Min connected pixels cutoff for a sphere sybr signal = bacterium
min_bact_size = round( (4/3)*pi*(bact_rad^3)/vox );
min_visc_size = min_bact_size*5; % min visc inside region > bacterium
min_visc_size2 = min_visc_size*5; % min visc edge region must be larger
                                  % due to more noise at lower visc
% Histogram bins
visc_max = 100; % max visc for histcounts
visc_delta = 0.1; % visc bin width
grad_max = 100; % max grad for histcounts
grad_delta = 0.1; % grad bin width
visc_bins = 0:visc_delta:visc_max; % visc bins for histcounts
grad_bins = 0:grad_delta:grad_max; % grad bins for histcounts
vbin = visc_bins(1:end-1)+visc_delta/2; % visc bin centers for plots
gbin = grad_bins(1:end-1)+grad_delta/2; % grad bin centers for plots

% Viscosity gradient magnitude
[gradx,grady,gradz]=gradient(vim,mpp,mpp,mpz);
gim = sqrt(gradx.^2+grady.^2+gradz.^2);

disp(nm);

%% ------------------------------------------------------------------------
% IDENTIFY BACTERIA
% -------------------------------------------------------------------------
tic
% Locate connected sybr pixels above thresholds
symask=esf>=syth; % Find pixels greater than SYBR threshold
symask_cc=bwconncomp(symask,26); % Locate individual clusters (26=3D cubic)
[~,I] = sort(cellfun(@length,symask_cc.PixelIdxList),'descend');
symask_cc.PixelIdxList=symask_cc.PixelIdxList(I); % Sort by size
numbgt=cellfun(@numel,symask_cc.PixelIdxList); % Pixels per cluster
indbgt=find(numbgt > min_bact_size); % Only include >bact-sized clusters
indbgt(ismember(indbgt,syig))=[]; % Ignore certain sybr components
indbgtx=cat(1,symask_cc.PixelIdxList{indbgt}); % Bact pixel indicies

baob=numel(indbgt); % Number of bact objects
baco=sum(ceil(numbgt(indbgt)/(min_bact_size*5))); % Conservative bact count
disp(['Bact Obj: ' int2str(baob) ', Bact Cnt: ' int2str(baco)]);

% Initial sybr array
sybr=zeros(size(esf));
sybr(indbgtx) = 1;

% Bacteria: buffer the sybr signal to reasonable bacteria size
syb_bwd=bwdistsc(sybr,[mpp mpp mpz]);
bact=double(syb_bwd <= bact_buffer); 

% Halos: dilate bacteria by halo distance
bact_and_halos=double(syb_bwd <= halo_delta+bact_buffer); 
halo=bact_and_halos-bact; % Subtract bact to leave only halos

%halo(halo==0)=NaN; % Ignore non-halo pixels (for histcounts)

disp(['Halo total px: ' int2str(sum(bact_and_halos(:)-bact(:)))]); 
fprintf('ID Bact: %3.1f min\n',toc/60); % status

%% ------------------------------------------------------------------------
% PARTITION VISCOSITY REGIONS
% -------------------------------------------------------------------------
% SEPARATE REGIONs---------------------------------------------------------

% Locate connected visc pixels above threshold
vimask=vim >= vith; % Find pixels greater than visc threshold for edge
vimask_cc=bwconncomp(vimask,26); % Locate individual clusters (26=3D cubic)
[~,I] = sort(cellfun(@length,vimask_cc.PixelIdxList),'descend');
vimask_cc.PixelIdxList=vimask_cc.PixelIdxList(I); % Sort by size
numvgt=cellfun(@numel,vimask_cc.PixelIdxList); % Pixels per cluster
indvgt=find(numvgt > min_visc_size2); % Only include > threshold-sized clusters

% Ignore / include list of connected components
if ~isempty(viig) 
    for i=1:size(viig,1)
        switch viig{i,1}
            case 'ig' % ignore cc for edge
                indvgt(ismember(indvgt,viig{i,2}))=[];
            case 'in' % include only these cc for edge
                indvgt=viig{i,2};
        end
    end
end

indvgtx=cat(1,vimask_cc.PixelIdxList{indvgt}); % Visc pixel indicies

% Initial agg visc array
agg0=zeros(size(vim));
agg0(indvgtx) = 1;

% Determine regions by distance from >= viscosity threshold
visc_bwd=bwdistsc(agg0,[mpp mpp mpz]);
agg=double(visc_bwd <= edg_buffer); % Aggregate region buffered

out=ones(size(vim)); 
out(logical(agg))=0; % outside: remove aggregate pixels.

% Remove saturated pixels, from ery
if isfield(im.m,'satpx')
    agg(im.m.satpx)=0;
    out(im.m.satpx)=0;
end

% Remove volumes using virm
if ~isempty(virm)
    virmm=false(size(vim)); % removal matrix
    [ci,ri]=meshgrid(1:size(vim,1),1:size(vim,2)); % single plane indices

    for i=1:size(virm,1) % Rows of bgin
        for j=virm{i,1}  % z planes
            virmm(:,:,j)=inpolygon(ci,ri,virm{i,2},virm{i,3});
        end
        agg(virmm)=0;
        out(virmm)=0;
    end
end

% Keep volumes using vike
if ~isempty(vike)
    vikem=false(size(vim)); % keep matrix
    [ci,ri]=meshgrid(1:size(vim,1),1:size(vim,2)); % single plane indices

    for i=1:size(vike,1) % Rows of bgin
        for j=vike{i,1}  % z planes
            vikem(:,:,j)=inpolygon(ci,ri,vike{i,2},vike{i,3});
        end
    end
    agg(~vikem)=0;
    out(~vikem)=0;
end

% Halos in regions
halo_edge = halo.*agg;
halo_outside = halo.*out;

% Remove bacteria and halos from region
agg(logical(bact_and_halos)) = 0;
out(logical(bact_and_halos)) = 0;

% ALLOCATE VISCOSITIES & GRADIENTS-----------------------------------------
% Regions
ravm=agg.*vim;
ragm=agg.*gim;
rovm=out.*vim;
rogm=out.*gim;

rtvm=[ravm(:) rovm(:)];
rtgm=[ragm(:) rogm(:)];

% Halos
havm=halo_edge.*vim;
hagm=halo_edge.*gim;
hovm=halo_outside.*vim;
hogm=halo_outside.*gim;

htvm=[havm(:) hovm(:)];
htgm=[hagm(:) hogm(:)];

fprintf('Visc Regions: %3.1f min\n',toc/60); % status

%% ------------------------------------------------------------------------
% HISTCOUNTS & PROBABILITIES
% -------------------------------------------------------------------------

p=@(n) n./sum(n); % Calculate probabilities from histcounts

% Aggregate region
[havc,~]=histcounts(nonzeros(havm),visc_bins);
[ravc,~]=histcounts(nonzeros(ravm),visc_bins);
phav=p(havc);% Prob halo visc
prav=p(ravc); % Prob region visc
rav=phav./prav; % Ratio of probabilities

[hagc,~]=histcounts(nonzeros(hagm),grad_bins);
[ragc,~]=histcounts(nonzeros(ragm),grad_bins);
phag=p(hagc); % Prob halo grad
prag=p(ragc); % Prob region grad
rag=phag./prag; % Ratio of probabilities

% Outside region
[hovc,~]=histcounts(nonzeros(hovm),visc_bins);
[rovc,~]=histcounts(nonzeros(rovm),visc_bins);
phov=p(hovc); % Prob halo visc
prov=p(rovc); % Prob region visc
rov=phov./prov; % Ratio of probabilities

[hogc,~]=histcounts(nonzeros(hogm),grad_bins);
[rogc,~]=histcounts(nonzeros(rogm),grad_bins);
phog=p(hogc); % Prob halo grad
prog=p(rogc); % Prob region grad
rog=phog./prog; % Ratio of probabilities

% Total regions
[htvc,~]=histcounts(nonzeros(htvm),visc_bins);
[rtvc,~]=histcounts(nonzeros(rtvm),visc_bins);
phtv=p(htvc); % Prob halo visc
prtv=p(rtvc); % Prob region visc
rtv=phtv./prtv; % Ratio of probabilities

[htgc,~]=histcounts(nonzeros(htgm),grad_bins);
[rtgc,~]=histcounts(nonzeros(rtgm),grad_bins);
phtg=p(htgc); % Prob halo grad
prtg=p(rtgc); % Prob region grad
rtg=phtg./prtg; % Ratio of probabilities

disp(['Halo agg px: ' int2str(sum(havc))]);
disp(['Agg px: ' int2str(sum(ravc)) ', vol: ' num2str(sum(ravc)*vox)]);
fprintf('Hist: %3.1f min\n',toc/60); % status

%% ------------------------------------------------------------------------
% SAVE FILE
% -------------------------------------------------------------------------

% package output
c.v.havc=havc;
c.v.hovc=hovc;
c.v.ravc=ravc;
c.v.rovc=rovc;

c.g.hagc=hagc;
c.g.hogc=hogc;
c.g.ragc=ragc;
c.g.rogc=rogc;

c.m=im.m;
c.m.vox=vox;
c.m.baob=baob;
c.m.baco=baco;
c.m.vbin=vbin;
c.m.gbin=gbin;
c.m.halos.bac.syth=syth;
c.m.halos.bac.bact_rad=bact_rad;
c.m.halos.bac.bact_buffer=bact_buffer;
c.m.halos.bac.halo_delta=halo_delta;
c.m.halos.reg.vith=vith;
c.m.halos.reg.edg_buffer=edg_buffer;
c.m.halos.syig=syig;
c.m.halos.viig=viig;
c.m.halos.virm=virm;
c.m.halos.vike=vike;

if saveout
    % Probability data
    if ~isempty(svst)
        load rcd.mat;
        rc.(svst).(nm).v=c.v;
        rc.(svst).(nm).g=c.g;
        rc.(svst).(nm).m.vox=vox;
        rc.(svst).(nm).m.baco=baco;
        save('rcd.mat','rc','-v7.3');
    end
    
    % Output file (visc)
    cv.ravm=ravm;
    cv.rovm=rovm;
    cv.havm=havm;
    cv.hovm=hovm;
    cv.v=c.v;
    cv.m=c.m;
    save([nm xg '_cv.mat'],'cv','-v7.3');

    % Output file (grad)
    cg.ragm=ragm;
    cg.rogm=rogm;
    cg.hagm=hagm;
    cg.hogm=hogm;
    cg.g=c.g;
    cg.m=c.m;
    save([nm xg '_cg.mat'],'cg','-v7.3');

end

%% ------------------------------------------------------------------------
% FIGURES
% -------------------------------------------------------------------------

if plotfig
    
    sbt=15; % small bin threshold

    % Aggregate probability figures----------------------------------------
    f(1)=figure('Name',['rc_c visc ' im.m.nm]); % Viscosities

    % Halo visc probabilities
    subplot(2,2,1) 
    semilogy(vbin,phav)
    hold on
    semilogy(vbin,phov)
    semilogy(vbin,phtv)
    xlabel 'Viscosity';
    ylabel 'P(halo)';
    legend('Agg','Out','Tot');
    axis([1 5 1e-3 1.5])
    title 'Halo Visc Prob';
    grid on

    % Region visc probabilities
    subplot(2,2,2) 
    semilogy(vbin,prav)
    hold on
    semilogy(vbin,prov)
    semilogy(vbin,prtv)
    xlabel 'Viscosity';
    ylabel 'P(region)';
    axis([1 5 1e-3 1.5])
    title 'Region Visc Prob';
    grid on
    
    % Aggregate visc probability ratio
    abhv=havm(havm<visc_max);
    noith1=35*std([-abhv;abhv]/mean(abhv)); % kludgy small value cutoff
    noith2=vbin(find(havc<sbt & vbin>=2,1));
    noith=min([noith1 noith2]);
    
    subplot(2,2,3) 
    ins=prav~=0 & vbin>=1; % prevent divide-by-0 nans
    plot(vbin(ins),phav(ins)./prav(ins),'k','linewidth',2)
    xlabel('Relative Viscosity')
    ylabel('P(halo)/P(region)')
    hold on
    plot([0 visc_max],[1 1],'r')
    plot([noith noith],[0 20],'--r','linewidth',1)
    if all(isnan(phav(ins&vbin<noith))) || all(phav(ins&vbin<noith)==0)
        axis([1 1.05*noith 0 5])
    else
        axis([1 1.05*noith 0 1.1*max(phav(ins&vbin<noith)./prav(ins&vbin<noith))])
    end
    title(['Agg Prob Ratio, vith=' num2str(vith)])
    grid on
    

    % Outside visc probability ratio
    obhv=hovm(hovm<visc_max);
    noith1=35*std([-obhv;obhv]/mean(obhv)); % kludgy small value cutoff
    noith2=vbin(find(hovc<sbt & vbin>=2,1));
    noith=min([noith1 noith2]);
    
    subplot(2,2,4) 
    ins=prov~=0 & vbin>=1; % prevent divide-by-0 nans
    plot(vbin(ins),phov(ins)./prov(ins),'k','linewidth',2)
    xlabel('Relative Viscosity')
    ylabel('P(halo)/P(region)')
    hold on
    plot([0 visc_max],[1 1],'r')
    plot([noith noith],[0 20],'--r','linewidth',1)
    if all(isnan(phov(ins&vbin<noith))) || all(phov(ins&vbin<noith)==0)
        axis([1 1.05*noith 0 5])
    else
        axis([1 1.05*noith 0 1.1*max(phov(ins&vbin<noith)./prov(ins&vbin<noith))])
    end
    title('Outside Prob Ratio')
    grid on

    % Gradient probabilities figures---------------------------------------
    f(2)=figure('Name',['rc_c grad ' im.m.nm]); % Gradients

    % Halo grad probabilities
    subplot(2,2,1)
    semilogy(gbin,phag)
    hold on
    semilogy(gbin,phog)
    semilogy(gbin,phtg)
    xlabel 'Viscosity Gradient';
    ylabel 'P(halo)';
    axis([0 10 1e-3 1.5])
    legend('Agg','Out','Tot');
    title 'Halo Grad Prob'
    grid on
    
    % Region grad probabilities
    subplot(2,2,2)
    semilogy(gbin,prag)
    hold on
    semilogy(gbin,prog)
    semilogy(gbin,prtg)
    xlabel 'Viscosity Gradient';
    ylabel 'P(region)';
    axis([0 10 1e-3 1.5])
    title('Region Grad Prob')
    grid on

    % Aggregate grad probability ratio
    noith=10;
    subplot(2,2,3)
    ins=prag~=0; % prevent divide-by-0 nans
    plot(gbin(ins),phag(ins)./prag(ins),'k','linewidth',2)
    xlabel('Relative Viscosity Gradient ({\mu}m^{-1})')
    ylabel('P(halo)/P(region)')
    hold on
    plot([0 grad_max],[1 1],'r')
    axis([[-0.05 1.05]*noith 0 5])
    title('Agg Prob Ratio')
    grid on
    
    % Outside grad probability ratio
    noith=gbin(find(hogc<sbt,1));
    subplot(2,2,4)
    ins=prog~=0; % prevent divide-by-0 nans
    plot(gbin(ins),phog(ins)./prog(ins),'k','linewidth',2)
    xlabel('Relative Viscosity Gradient ({\mu}m^{-1})')
    ylabel('P(halo)/P(region)')
    hold on
    plot([0 grad_max],[1 1],'r')
    plot([noith noith],[0 20],'--r','linewidth',1)
    axis([[-0.05 1.05]*noith 0 5])
    title('Outside Prob Ratio')
    grid on
    

    %% Region and Halo visualization ---------------------------------------
    clm=5; % caxis limit max
    mpos=get(0,"MonitorPositions"); [yc,xc,zc]=size(vim);

    % log10 vim
    for i=1:size(agg,3)
        eo(:,:,i)=agg(:,:,i)-imerode(agg(:,:,i),[0 1 0; 1 1 1; 0 1 0]); %#ok<SAGROW>
    end
    vio=vim; vio(vio<1)=1;
    vio(logical(eo))=-clm+2;

    f2(1)=figure('Name',['rc_c vim ' im.m.nm]);
    s(1)=sliceViewer(vio);
    % f2(1).Position=[mpos(end,1)+25 ...
    %     mpos(end,2)+0.5*mpos(end,4)-50 ...
    %     0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
    s(1).Colormap=[flipud(parula);gray];
    s(1).DisplayRange=[-clm+2 clm];

    % Combined region and halo results    
    hrc=-clm*(1*out+0.5*agg)+hovm+havm; % combine
    
    f2(2)=figure('Name',['rc_c region+halos ' im.m.nm]);
    s(2)=sliceViewer(hrc);
    % f2(2).Position=[mpos(end,1)+40+0.5*mpos(end,4)*xc/yc ...
    %     mpos(end,2)+0.5*mpos(end,4)-50 ...
    %     0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
    s(2).Colormap=[gray;parula];
    s(2).DisplayRange=[-clm clm];

    % log10 sybr
    f2(3)=figure('Name',['rc_c log sybr ' im.m.nm]);
    s(3)=sliceViewer(esf);
    % f2(3).Position=[mpos(end,1)+55+mpos(end,4)*xc/yc ...
    %     mpos(end,2)+0.5*mpos(end,4)-50 ...
    %     0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
    s(3).Colormap=gray;
    clim('auto');
    set(gca,'ColorScale','log')

    % Link the sliceViewer sliders
    addlistener(s(1), 'SliderValueChanging', ...
        @(src,evt) updateSliceNumber(s(1), s(2), s(3)));
    
    addlistener(s(2), 'SliderValueChanging', ...
        @(src,evt) updateSliceNumber(s(2), s(1), s(3)));
    
    addlistener(s(3), 'SliderValueChanging', ...
        @(src,evt) updateSliceNumber(s(3), s(1), s(2)));

end

function updateSliceNumber(s1, s2, s3)
    % Update the SliceNumber property of s2 to match s1
    s2.SliceNumber = s1.SliceNumber;
    s3.SliceNumber = s1.SliceNumber;
end