%% viewVisc: view RY3 red, RY3 blue, SYBR, and viscosity images in a GUI
%
%  Note: requires rc_a and rc_b outputs, Image Processing Toolbox

clearvars;
% FILES--------------------------------------------------------------------
nm='e01_m09r15'; % Filename
clm=[1 10]; % Color scale limits for visc only

load([nm '_a.mat']); % Load output from rc_a
load([nm '_b.mat']); % Load output from rc_b

% Prepare images
im.vim=b.vim;
im.esf=b.esf;

mfwin=[5 5];    % Medfilt2 pixel window
gawin=5;        % Imgaussfilt sigma
for i=1:size(a.ery,3) % z planes
    im.enf(:,:,i)=medfilt2(a.ery(:,:,i),mfwin); %#ok<*SAGROW> % Numerator (red)
    im.edf(:,:,i)=imgaussfilt(a.ebl(:,:,i),gawin);  % Denominator (blue)
end

%% GUI function
viewV(im,nm,clm);

function viewV(im,nm,cl)

    % Parameters
    zi=1; % Z-plane index
    [yc,xc,zc]=size(im.vim); % y,x pixel and Z-plane count
    
    % Create ui figure
    fig = uifigure("Name",['viewVisc: ' nm]);
    g = uigridlayout(fig,[3 4]);
    g.RowHeight = {'1x','1x','fit'};
    g.ColumnWidth = {'1x','1x','1x','1x'};
    
    % Position ui figure (upper left corner, last monitor)
    mpos=get(0,"MonitorPositions");
    % fig.Position = [mpos(end,1)+25 ...
    %     mpos(end,2)+0.5*mpos(end,4)-50 ...
    %     0.5*mpos(end,4)*xc/yc 0.5*mpos(end,4)];
    
    % Create ui elements
    ax(1) = uiaxes(g);
    ax(1).Layout.Row = 1;
    ax(1).Layout.Column = [1 2];
    %ax(1).Toolbar.Visible = 'off';
    
    ax(2) = uiaxes(g);
    ax(2).Layout.Row = 1;
    ax(2).Layout.Column = [3 4];
    
    ax(3) = uiaxes(g);
    ax(3).Layout.Row = 2;
    ax(3).Layout.Column = [1 2];
    
    ax(4) = uiaxes(g);
    ax(4).Layout.Row = 2;
    ax(4).Layout.Column = [3 4];
    
    bp = uibutton(g, ...
        "Text","Prev", ...
        "ButtonPushedFcn", @prevButtonPushed);
    bp.Layout.Row = 3;
    bp.Layout.Column = 3;
    
    bn = uibutton(g, ...
        "Text","Next", ...
        "ButtonPushedFcn", @nextButtonPushed);
    bn.Layout.Row = 3;
    bn.Layout.Column = 4;
    
    lc0 = uilabel(g,"Text","Z-Plane: ","HorizontalAlignment","right");
    lc0.Layout.Row = 3;
    lc0.Layout.Column = 1;
    
    lc = uilabel(g,"Text",sprintf("%d / %d",zi,zc));
    lc.Layout.Row = 3;
    lc.Layout.Column = 2;
    
    % Initialize plots
    updatePlot;
    
    titles={'RY3 Red','RY3 Blue','SYBR','Rel Visc'};

    for i=1:length(ax)
        ax(i).PlotBoxAspectRatioMode='manual';
        ax(i).PlotBoxAspectRatio=[xc/yc 1 1];
        ax(i).XLim=[1 xc];
        ax(i).YLim=[1 yc];
        ax(i).Box='on';
        ax(i).XTick=[];
        ax(i).XTickLabel='';
        ax(i).YTick=[];
        ax(i).YTickLabel='';

        title(ax(i),titles{i});
        colorbar(ax(i));
    end
    
    % UI Functions
    
    function prevButtonPushed(~,~)
        if zi>1
            zi=zi-1;
            updatePlot;
        end        
    end
    
    function nextButtonPushed(~,~)
        if zi<zc
            zi=zi+1;
            updatePlot;
        end
    end
    
    function updatePlot
        cla(ax);
        
        imagesc(ax(1),im.enf(:,:,zi));
        imagesc(ax(2),im.edf(:,:,zi));
        imagesc(ax(3),im.esf(:,:,zi));
        imagesc(ax(4),im.vim(:,:,zi));

        set(ax,'ColorScale','log'); % Log10 color scale
        clim(ax(1:3),'auto');
        clim(ax(4),cl);
        lc.Text = sprintf("%d / %d",zi,zc);        
    end

end